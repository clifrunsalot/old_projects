

import os, sys

print os.listdir(sys.argv[1])
