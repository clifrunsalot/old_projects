import os, sys, re


def usage():
  """
  Usage: [python] ./formatLog <file>

  where <file> is the file.

  The output is a file of the same name with '.clean' appended.

  """
  print usage.__doc__


def cleanFile(file):
  """
  Reads file, removes misplaced newlines, and reformats each log
  entry.
  file - Name of log.
  """
  fin = open(file)
  bigString = ""

  # Remove all newlines
  newList = fin.readlines()

  try:
    for i in newList:
      bigString = bigString + ' ' + i.strip()
  except Exception, e:
    print e

  # Create pattern and compile
  start_patt = r'(Requirement|Debug).*?-\s'
  patt = re.compile('(' + start_patt + '.*?)(?=' + start_patt + ')')
  print patt.pattern
#  print bigString

  # Create new list
  allEntries = re.findall(patt,bigString)
#  print len(allEntries)
  return allEntries

def printList(l, f):
  """
  Prints items in list.
  l - List
  f - Name of output file
  """
  outfile = open(f, 'w')
  for ln in l:
    # Print first item of each element in array.
    outfile.write(ln[0] + '\n')
  outfile.close();

if __name__ == "__main__":
  try:
    if len(sys.argv) == 2:
      infile = sys.argv[1]
      if os.path.exists(sys.argv[1]):
        outfile = sys.argv[1] + '.clean'
        tList = cleanFile(sys.argv[1])
        printList(tList, outfile)
      else:
        print sys.argv[1], ' does not exist! '
    else:
      usage()

  except Exception,e:
    msg = 'Error: ' + sys.argv[0] + ' was unable to process ' + sys.argv[1] + '. Check log.'
    print msg
  
