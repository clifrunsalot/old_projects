#include <iostream>
#include <ScBasicTypes.h>
#include <ScGenericStatus.h>
#include "StandinWcpServer.h"
#include "StandinWssServer.h"
#include "GUIDTypeSerialized.h"

#ifndef WMIS_SIM_SENDER_H
#define WMIS_SIM_SENDER_H

class Sender
{
  public:

	// Notification IDs
    static const sc::String NOT_WCP_CONTRACT_ID;
    static const sc::String NOT_CURRENT_ALERTS_WSS_CONTRACT_ID;
    static const sc::String NOT_HISTORY_ALERTS_WSS_CONTRACT_ID;
    static const sc::String NOT_ALERT_COUNTS_WSS_CONTRACT_ID;

	// FEC IDs
    static const sc::String FEC_WCP_CONTRACT_ID;
    static const sc::String FEC_EFFECTOR_WSS_CONTRACT_ID;
    static const sc::String FEC_FIRE_MISSIONS_WSS_CONTRACT_ID;
    static const sc::String FEC_MISSION_PROGRESSION_WSS_CONTRACT_ID;
    static const sc::String FEC_MISSION_TARGET_WSS_CONTRACT_ID;
    static const sc::String FEC_MTO_WSS_CONTRACT_ID;
    static const sc::String FEC_OBSERVER_WSS_CONTRACT_ID;
 	
    
    Sender(
        wmis::StandinWcpServer* wcpServer,
        wmis::StandinWssServer* wssServer);
        
    static void* runThread(void* arg);
    
    void mainMenu(Sender* sender);
    void wssMenu(Sender* sender, sc::String contractId);

    void subWss(sc::String contractId);
    void stopWss(sc::String contractId);
    void startWss(sc::String contractId);
    void unsubWss(sc::String contractId);
    
	// Notification messages
    void reqTamperDetails();
    void reqCbrnDetails();
    void reqNoAckDetails();
    void reqClearAcked();
	
	// FEC messages
    void reqCancelCheckFireAll();
    void reqCancelCheckFireSelected();
    void reqCheckFireAll();
    void reqCheckFireSelected();
    void reqEndOfMission();
    void reqFireAtMyCommand();
    void reqSetMissionProgressionComments();  

    pthread_t m_thread; 

    wmis::StandinWcpServer* m_wcpServer;
    wmis::StandinWssServer* m_wssServer;
    
};

#endif // WMIS_SIM_SENDER_H
