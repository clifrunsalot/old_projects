#include <ScBasicTypes.h>
#include <ScGenericStatus.h>
#include "StandinWcpServer.h"
#include "StandinWssServer.h"
#include "Sender.h"
#include "Receiver.h"

#ifndef WMIS_SIM_SIMULATOR_H
#define WMIS_SIM_SIMULATOR_H

class WmisSimulator
{
  public:
  
    WmisSimulator();
    virtual ~WmisSimulator();
    
    sc::ScStatus startUp(sc::String sessionId);
  
  private:
    
    wmis::StandinWcpServer* m_wcpServer;
    wmis::StandinWssServer* m_wssServer;
    Sender* m_sender;
    Receiver* m_receiver;
};

#endif // WMIS_SIM_SIMULATOR_H
