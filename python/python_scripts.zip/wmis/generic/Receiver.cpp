//-----------------------------------------------------------------------------
// COMPANY NAME: Raytheon Company
// COPYRIGHT: Copyright (c) 2008 Raytheon Company
// UNPUBLISHED WORK
// ALL RIGHTS RESERVED
// PROJECT NAME: FCS BCME
// CONTRACT NUMBER: 3EC1721
//
// @author  cbhuds          BCME-????
// @version BCME-????       2008-MAR-13     Initial version.
//
//-----------------------------------------------------------------------------

#include <iostream>
#include <ScBasicTypes.h>
#include <ScGenericStatus.h>
#include <WmisMessage.h>
#include <WssMessage.h>
#include "Receiver.h"
#include "StandinWcpServer.h"
#include "StandinWssServer.h"

Receiver::Receiver(
    wmis::StandinWcpServer* wcpServer,
    wmis::StandinWssServer* wssServer) :
        m_wcpServer(wcpServer),
        m_wssServer(wssServer),
        m_thread(0)
{
    pthread_create(&m_thread, 0, runThread, (void*)(this));
}

void* Receiver::runThread(void* arg)
{
    const sc::Int ONE_SECOND_TIMEOUT = 1000;

    Receiver* receiver = static_cast<Receiver*>(arg);

    sc::ScStatus receiveStatus = SC_FAILED;

    wmis::WmisMessage wcpMsg;
    wmis::WssMessage wssMsg;

    do
    {
        receiveStatus = receiver->m_wcpServer->receive(wcpMsg,
            ONE_SECOND_TIMEOUT);
        if (receiveStatus == SC_SUCCESS)
        {
            receiver->processWcpMessage(wcpMsg);
        }

        receiveStatus = receiver->m_wssServer->receive(wssMsg,
            ONE_SECOND_TIMEOUT);
        if (receiveStatus == SC_SUCCESS)
        {
            receiver->processWssMessage(wssMsg);
        }
    }
    while(true);
}

void Receiver::processWcpMessage(wmis::WmisMessage msg)
{
    std::cout << "WCP Message Receved:" << std::endl;
    std::cout << msg << std::endl << std::endl;
}

void Receiver::processWssMessage(wmis::WssMessage msg)
{
    std::cout << "WSS Message Received:" << std::endl;
    std::cout << msg << std::endl << std::endl;
}
