//-----------------------------------------------------------------------------
// COMPANY NAME: Raytheon Company
// COPYRIGHT: Copyright (c) 2008 Raytheon Company
// UNPUBLISHED WORK
// ALL RIGHTS RESERVED
// PROJECT NAME: FCS BCME
// CONTRACT NUMBER: 3EC1721
//
// @author	cbhuds			BCME-????
// @version BCME-????		2008-MAR-13		Initial version.
//
//-----------------------------------------------------------------------------

#include <iostream>
#include <ScBasicTypes.h>
#include <ScGenericStatus.h>
#include <WmisMessage.h>
#include <WssMessage.h>
#include "Sender.h"
#include "StandinWcpServer.h"
#include "StandinWssServer.h"

// AC includes

// CMM includes

// FEC includes
#include "EffectorDetailsQueryTypeSerialized.h"
#include "FireMissionsQueryTypeSerialized.h"
#include "MissionProgressionDetailsQueryTypeSerialized.h"
#include "MissionTargetDetailsQueryTypeSerialized.h"
#include "MTODetailsQueryTypeSerialized.h"
#include "ObserverDetailsQueryTypeSerialized.h"

// FOM includes

// Notification includes
#include "GUIDTypeSerialized.h"
#include "UgsCurrentAlertsQueryTypeSerialized.h"




//-------------------------//
//                         //
// Service name constants  //
//                         //
//-------------------------//
const int ac   = 1
const int cmm  = 2
const int fec  = 3
const int fom  = 4
const int noti = 5
const int to   = 6

//
// TO constants
//

 
//
// AC constants
//


//
// CMM constants
//


//
// FEC constants
//
const sc::String Sender::FEC_WCP_CONTRACT_ID =
	"id_fcccme_fec_ui0031_srv_SRV0031";
const sc::String Sender::FEC_EFFECTOR_WSS_CONTRACT_ID =
	"id_fcccme_fec_ui0031_wss_EffectorDetails";
const sc::String Sender::FEC_FIRE_MISSIONS_WSS_CONTRACT_ID =
	"id_fcccme_fec_ui0031_wss_FireMissions";
const sc::String Sender::FEC_MISSION_PROGRESSION_WSS_CONTRACT_ID =
	"id_fcccme_fec_ui0031_wss_MissionProgressionDetails";
const sc::String Sender::FEC_MISSION_TARGET_WSS_CONTRACT_ID =
	"id_fcccme_fec_ui0031_wss_MissionTargetDetails";
const sc::String Sender::FEC_MTO_WSS_CONTRACT_ID =
	"id_fcccme_fec_ui0031_wss_MTODetails";
const sc::String Sender::FEC_OBSERVER_WSS_CONTRACT_ID =
	"id_fcccme_fec_ui0031_wss_ObserverDetails";

//
// FOM constants
//


//
// NOT constants
//
const sc::String Sender::NOT_WCP_CONTRACT_ID =
	"id_fcccme_not_ui0073_srv_SRV0073";
const sc::String Sender::NOT_CURRENT_ALERTS_WSS_CONTRACT_ID =
	"id_fcccme_not_ui0073_wss_UgsCurrentAlerts";
const sc::String Sender::NOT_HISTORY_ALERTS_WSS_CONTRACT_ID =
	"id_fcccme_not_ui0073_wss_UgsHistoryAlerts";
const sc::String Sender::NOT_ALERT_COUNTS_WSS_CONTRACT_ID =
	"id_fcccme_not_ui0073_wss_UgsTotalUnacknowledgedAlertCounts";

//
// TO constants
//


//-------------//
//             //
// Contructor  //
//             //
//-------------//
Sender::Sender(
	wmis::StandinWcpServer* wcpServer,
	wmis::StandinWssServer* wssServer) :
		m_wcpServer(wcpServer),
		m_wssServer(wssServer),
		m_thread(0)
{
	pthread_create(&m_thread, NULL, runThread, (void*)(this));
}

//-------------//
//             //
// Destrructor //
//             //
//-------------//
Sender::~Sender(
	wcpServer(0),
	wssServer(0)) :
		m_wcpServer(wcpServer),
		m_wssServer(wssServer),
		m_thread(0)
{
}


//-------------------//
//                   //
// Message handlers  //
//                   //
//-------------------//

//
// This spawns a thread to manage the sending of messages
//
void* Sender::runThread(void* arg)
{
	Sender* sender = static_cast<Sender*>(arg);

	if (sender)
	{
		do
		{
			sender->mainMenu(sender);
		}
		while(true);
	}
}

//
// This method handles AC messages
//
void Sender::handleAcMessages(Sender *sender, sc::String contractId)
{
	if (contractId == "change this")
	{

	}
	else
	{
		std::cout << "ERROR: Unable to process AC contract ID: " 
			<< contractId << " because it is an unknown type"
			<< std::endl;
	}
}

//
// This method handles CMM messages
//
void Sender::handleCmmMessages(Sender *sender, sc::String contractId)
{
	if (contractId == "change this")
	{

	}
	else
	{
		std::cout << "ERROR: Unable to process CMM contract ID: " 
			<< contractId << " because it is an unknown type"
			<< std::endl;
	}
}

//
// This method handles FEC messages
//
void Sender::handleFecMessages(Sender *sender, sc::String contractId)
{
	if (contractId == "change this")
	{
		sender->reqCancelCheckFireAll();
	}
	else if (contractId == "change this")
	{

	}
	else
	{
		std::cout << "ERROR: Unable to process CMM contract ID: " 
			<< contractId << " because it is an unknown type"
			<< std::endl;
	}
			sender->reqCancelCheckFireSelected();
			break;
		case 3:
			sender->reqCheckFireAll();
			break;
		case 4:
			sender->reqCheckFireSelected();
			break;
		case 5:
			sender->reqEndOfMission();
			break;
		case 6:
			sender->reqFireAtMyCommand();
			break;
		case 7:
			sender->reqSetMissionProgressionComments();
			break;
		default:
			std::cout << "Invalid menu choice - try again." << std::endl;
			break;
	}
}

//
// This method handles FOM messages
//
void Sender::handleFomMessages(Sender *sender, sc::String contractId)
{
	if (contractId == "change this")
	{

	}
	else
	{
		std::cout << "ERROR: Unable to process FOM contract ID: " 
			<< contractId << " because it is an unknown type"
			<< std::endl;
	}
}

//
// This method handles NOT messages
//
void Sender::handleNotMessages(Sender *sender, int choice)
{
	switch (choice)
	{
		case 1:
			sender->reqTamperDetails();
			break;
		case 2:
			sender->reqCbrnDetails();
			break;
		case 3:
			sender->reqNoAckDetails();
			break;
		case 4:
			sender->reqClearAcked();
			break;
		default:
			std::cout << "Invalid NOTIFICATION message type submitted" << std::endl;
			break;
}

//
// This method handles TO messages
//
void Sender::handleToMessages(Sender *sender, sc::String contractId)
{
	if (contractId == "change this")
	{

	}
	else
	{
		std::cout << "ERROR: Unable to process TO contract ID: " 
			<< contractId << " because it is an unknown type"
			<< std::endl;
	}
}

//
// This handles starting, pausing, resuming, and ending a subcription.
//
void Sender::handleSubscription(Sender *sender, sc::String contractId, int choice)
{
	switch (choice)
	{
		case 1:
			sender->subWss(contractId);
			break;
		case 2:
			sender->stopWss(contractId);
			break;
		case 3:
			sender->startWss(contractId);
			break;
		case 4:
			sender->unsubWss(contractId);
			break;
		default:
			std::cout << "ERROR: Unable to perform subscription action for " 
						<< contractId << " because the action " << choice << " is unknown" << std::endl;
			break;
	}
}

void Sender::mainMenu(Sender* sender)
{
	int choice = 0;

	std::cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" << std::endl;
	std::cout << "			MENU - Notification Service			   " << std::endl;
	std::cout << "												   " << std::endl;
	std::cout << " WSS Messages:								   " << std::endl;
	std::cout << " 1.  Current alerts							   " << std::endl;
	std::cout << " 2.  History alerts							   " << std::endl;
	std::cout << " 3.  Alert counts								   " << std::endl;
	std::cout << "												   " << std::endl;
	std::cout << " WCP Messages:								   " << std::endl;
	std::cout << " 4.  Request Tamper Alert details (implicit ack) " << std::endl;
	std::cout << " 5.  Request CBRN Alert details (implicit ack)   " << std::endl;
	std::cout << " 6.  Request No Ack Alert details (implicit ack) " << std::endl;
	std::cout << " 7.  Clear acknowledged alerts				   " << std::endl;
	std::cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" << std::endl;
	std::cout << "choice> ";

}

void Sender::process(Sender *sender, sc::String contractId, int service)
{
	switch (service)
	{
		case ac:
			sender.handleAcMessages(sender, contractId)
			break;
		case cmm:
			sender.handleCmmMessages(sender, contractId)
			break;
		case fec:
			sender.handleFecMessages(sender, contractId)
			break;
		case fom:
			sender.handleFomMessages(sender, contractId)
			break;
		case noti:
			sender.handleNotMessages(sender, contractId)
			break;
		case to:
			sender.handleToMessages(sender, contractId)
			break;
		default:
			std::cout << "Invalid service submitted - try again." << std::endl;
			break;
	}
}

void Sender::wssMenu(Sender* sender, sc::String contractId)
{
	int choice = 0;

	std::cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" << std::endl;
	std::cout << "		   MENU - WSS Message		   " << std::endl;
	std::cout << "									   " << std::endl;
	std::cout << " Choose an action for contract ID:   " << std::endl;
	std::cout << "	   " << contractId << std::endl;
	std::cout << "									   " << std::endl;
	std::cout << " 1.  Subscribe					   " << std::endl;
	std::cout << " 2.  Suspend						   " << std::endl;
	std::cout << " 3.  Resume						   " << std::endl;
	std::cout << " 4.  Unsubscribe					   " << std::endl;
	std::cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" << std::endl;
	std::cout << "choice> ";
	
	std::cin >> choice;

	switch (choice)
	{
		case 1:
			sender->subWss(contractId);
			break;
		case 2:
			sender->stopWss(contractId);
			break;
		case 3:
			sender->startWss(contractId);
			break;
		case 4:
			sender->unsubWss(contractId);
			break;
		default:
			std::cout << "Invalid menu choice - try again." << std::endl;
			break;
	}
}

//--------------------//
//                    //
// Standard messages  //
//                    //
//--------------------//

//
// This method subscribes to a message type
//
void Sender::subWss(sc::String contractId)
{
	wmis::WssMessage msg;
	msg.setContractId(contractId);
	msg.setAction(wmis::WssMessage::SUBSCRIBE);
	msg.setDispatchId("1234567890");

	if (contractid == NOT_WCP_CONTRACT_ID) {
		wmis::UgsCurrentAlertsQueryTypeSerialized queryData;
		queryData.writeToWmisMessage(msg, "WssData");
	} else if (contractId == FEC_EFFECTOR_WSS_CONTRACT_ID) {
		wmis::EffectorDetailsQueryTypeSerialized queryData;
		queryData.writeToWmisMessage(msg, "WssData");
	} else if (contractId == FEC_FIRE_MISSIONS_WSS_CONTRACT_ID) {
		wmis::FireMissionsQueryTypeSerialized queryData;
		queryData.writeToWmisMessage(msg, "WssData");
	} else if (contractId == FEC_MISSION_PROGRESSION_WSS_CONTRACT_ID) {
		wmis::MissionProgressionDetailsQueryTypeSerialized queryData;
		queryData.writeToWmisMessage(msg, "WssData");
	} else if (contractId == FEC_MISSION_TARGET_WSS_CONTRACT_ID) {
		wmis::MissionTargetDetailsQueryTypeSerialized queryData;
		queryData.writeToWmisMessage(msg, "WssData");
	} else if (contractId == FEC_MTO_WSS_CONTRACT_ID) {
		wmis::MTODetailsQueryTypeSerialized queryData;
		queryData.writeToWmisMessage(msg, "WssData");
	} else if (contractId == FEC_OBSERVER_WSS_CONTRACT_ID) {
		wmis::ObserverDetailsQueryTypeSerialized queryData;
		queryData.writeToWmisMessage(msg, "WssData");
	}

	queryData.neededOneParameter = "dummy";
	std::vector<sc::String> usedParams;
	usedParams.push_back("dummy");
	msg.setUsedParametersList(usedParams);
	sc::ScStatus status = m_wssServer->send(msg, contractId);
	std::cout << "sent the subscribe command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
	std::cout << statusStr << std::endl;
}


//
// This method suspends the subscription to a message type
//
void Sender::stopWss(sc::String contractId)
{
	wmis::WssMessage msg;
	msg.setContractId(contractId);
	msg.setAction(wmis::WssMessage::STOP_SUBSCRIPTION);
	msg.setDispatchId("1234567890");
	sc::ScStatus status = m_wssServer->send(msg, contractId);
	std::cout << "sent the stop command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
	std::cout << statusStr << std::endl;
}

//
// This method resumes the subscription to a message type
//
void Sender::startWss(sc::String contractId)
{
	wmis::WssMessage msg;
	msg.setContractId(contractId);
	msg.setAction(wmis::WssMessage::START_SUBSCRIPTION);
	msg.setDispatchId("1234567890");
	sc::ScStatus status = m_wssServer->send(msg, contractId);
	std::cout << "sent the start command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
	std::cout << statusStr << std::endl;
}

//
// This method stops the subscription to a message type
//
void Sender::unsubWss(sc::String contractId)
{
	wmis::WssMessage msg;
	msg.setContractId(contractId);
	msg.setAction(wmis::WssMessage::UNSUBSCRIBE);
	msg.setDispatchId("1234567890");
	sc::ScStatus status = m_wssServer->send(msg, contractId);
	std::cout << "sent the unsubscribe command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
	std::cout << statusStr << std::endl;
}

//+++++++++++++++++++++++++++++//
//                             //
// Service message assemblers  //
//                             //
//+++++++++++++++++++++++++++++//



//
// AC messages
//


//
// CMM messages
//



//
// FEC messages
//
void Sender::reqCancelCheckFireAll() {
	sc::String reason;
	std::cout << "Enter the reason for CheckFireAll: ";
	std::cin >> reason;

	wmis::WmisMessage msg;
	msg.setContractId(WCP_CONTRACT_ID);
	msg.setPrototypeId("reqCancelCheckFireAll");
	msg.setTransactionId(77);
   
	// Append serialized missionGUID
	wmis::GUIDTypeSerialized data;
	data.gUIDType = "Not Required";
	data.writeToWmisMessage(msg, "missionGUID");

	// Append serialized reason.
	msg.addStringParam("reason", reason);	 

	sc::ScStatus status = m_wcpServer->send(msg);
	std::cout << "sent the reqCancelCheckFireAll command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : 
		"unsuccessfully"; 
	std::cout << statusStr << std::endl;
}


void Sender::reqCancelCheckFireSelected() {
	sc::String missionId;
	std::cout << "Enter the selected Mission ID: ";
	std::cin >> missionId;

	sc::String reason;
	std::cout << "Enter the reason for CancelCheckFire: ";
	std::cin >> reason;

	wmis::WmisMessage msg;
	msg.setContractId(WCP_CONTRACT_ID);
	msg.setPrototypeId("reqCancelCheckFireSelected");
	msg.setTransactionId(77);
   
	// Append serialized missionGUID
	wmis::GUIDTypeSerialized data;
	data.gUIDType = missionId;
	data.writeToWmisMessage(msg, "missionGUID");

	// Append serialized
	msg.addStringParam("reason", reason);	
   
	sc::ScStatus status = m_wcpServer->send(msg);
	std::cout << "sent the reqCancelCheckFireSelected command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : 
		"unsuccessfully"; 
	std::cout << statusStr << std::endl;
}


void Sender::reqCheckFireAll() {
	sc::String reason;
	std::cout << "Enter the reason for CheckFireAll: ";
	std::cin >> reason;

	wmis::WmisMessage msg;
	msg.setContractId(WCP_CONTRACT_ID);
	msg.setPrototypeId("reqCheckFireAll");
	msg.setTransactionId(77);
   
	// Append serialized missionGUID
	wmis::GUIDTypeSerialized data;
	data.gUIDType = "Not Required";
	data.writeToWmisMessage(msg, "missionGUID");

	// Append serialized reason.
	msg.addStringParam("reason", reason);	 

	sc::ScStatus status = m_wcpServer->send(msg);
	std::cout << "sent the reqCheckFireAll command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : 
		"unsuccessfully"; 
	std::cout << statusStr << std::endl;
}


void Sender::reqCheckFireSelected() {
	sc::String missionId;
	std::cout << "Enter the selected Mission ID: ";
	std::cin >> missionId;

	sc::String reason;
	std::cout << "Enter the reason for CheckFire: ";
	std::cin >> reason;

	wmis::WmisMessage msg;
	msg.setContractId(WCP_CONTRACT_ID);
	msg.setPrototypeId("reqCheckFireSelected");
	msg.setTransactionId(77);
   
	// Append serialized missionGUID
	wmis::GUIDTypeSerialized data;
	data.gUIDType = missionId;
	data.writeToWmisMessage(msg, "missionGUID");

	// Append serialized
	msg.addStringParam("reason", reason);	
   
	sc::ScStatus status = m_wcpServer->send(msg);
	std::cout << "sent the reqCheckFireSelected command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : 
		"unsuccessfully"; 
	std::cout << statusStr << std::endl;
}

void Sender::reqEndOfMission() {
	sc::String missionId;
	std::cout << "Enter the selected Mission ID: ";
	std::cin >> missionId;

	sc::String reason;
	std::cout << "Enter the reason for EOM: ";
	std::cin >> reason;

	wmis::WmisMessage msg;
	msg.setContractId(WCP_CONTRACT_ID);
	msg.setPrototypeId("reqEndOfMission");
	msg.setTransactionId(77);
   
	// Append serialized missionGUID
	wmis::GUIDTypeSerialized data;
	data.gUIDType = missionId;
	data.writeToWmisMessage(msg, "missionGUID");

	// Append serialized
	msg.addStringParam("reason", reason);	

	sc::ScStatus status = m_wcpServer->send(msg);
	std::cout << "sent the reqEndOfMission command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : 
		"unsuccessfully"; 
	std::cout << statusStr << std::endl;
}

void Sender::reqFireAtMyCommand() {
	sc::String missionId;
	std::cout << "Enter the selected Mission ID: ";
	std::cin >> missionId;

	sc::String reason;
	std::cout << "Enter the reason for AMC: ";
	std::cin >> reason;

	wmis::WmisMessage msg;
	msg.setContractId(WCP_CONTRACT_ID);
	msg.setPrototypeId("reqFireAtMyCommand");
	msg.setTransactionId(77);
   
	// Append serialized missionGUID
	wmis::GUIDTypeSerialized data;
	data.gUIDType = missionId;
	data.writeToWmisMessage(msg, "missionGUID");

	// Append serialized
	msg.addStringParam("reason", reason);	

	sc::ScStatus status = m_wcpServer->send(msg);
	std::cout << "sent the reqFireAtMyCommand command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : 
		"unsuccessfully"; 
	std::cout << statusStr << std::endl;
}

void Sender::reqSetMissionProgressionComments() {
	sc::String missionId;
	std::cout << "Enter the selected Mission ID: ";
	std::cin >> missionId;

	sc::String state;
	std::cout << "Enter its status: ";
	std::cin >> state;

	sc::String comments;
	std::cout << "Enter Mission Progression Comment: ";
	std::cin >> comments;

	wmis::WmisMessage msg;
	msg.setContractId(WCP_CONTRACT_ID);
	msg.setPrototypeId("reqSetMissionProgressionComments");
	msg.setTransactionId(77);
   
	// Append serialized missionGUID
	wmis::GUIDTypeSerialized data1;
	data1.gUIDType = missionId;
	data1.writeToWmisMessage(msg, "missionGUID");

	// Append serialized statusGUID
	wmis::GUIDTypeSerialized data2;
	data2.gUIDType = state;
	data2.writeToWmisMessage(msg, "statusGUID");

	// Append serialized
	msg.addStringParam("comments", comments);	

	sc::ScStatus status = m_wcpServer->send(msg);
	std::cout << "sent the reqSetMissionProgressionComments command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : 
		"unsuccessfully"; 
	std::cout << statusStr << std::endl;

//
// FOM messages
//

//
// Notification messages
//
void Sender::reqTamperDetails()
{
	sc::String inString;
	std::cout << "Enter the selected Alert ID: ";
	std::cin >> inString;

	wmis::WmisMessage msg;
	msg.setContractId(NOT_WCP_CONTRACT_ID);
	msg.setPrototypeId("reqUgsAlertTamperDetail");
	msg.setTransactionId(77);
	wmis::GUIDTypeSerialized data;
	data.gUIDType = inString;
	data.writeToWmisMessage(msg, "alertGuid");
	sc::ScStatus status = m_wcpServer->send(msg);
	std::cout << "sent the reqUgsAlertTamperDetail command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
	std::cout << statusStr << std::endl;
}

void Sender::reqCbrnDetails()
{
	sc::String inString;
	std::cout << "Enter the selected Alert ID: ";
	std::cin >> inString;
	
	wmis::WmisMessage msg;
	msg.setContractId(NOT_WCP_CONTRACT_ID);
	msg.setPrototypeId("reqUgsRadiationDetail");
	msg.setTransactionId(77);
	wmis::GUIDTypeSerialized data;
	data.gUIDType = inString;
	data.writeToWmisMessage(msg, "alertGuid");
	sc::ScStatus status = m_wcpServer->send(msg);
	std::cout << "sent the reqUgsAlertTamperDetail command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
	std::cout << statusStr << std::endl;
}

void Sender::reqNoAckDetails()
{
	sc::String inString;
	std::cout << "Enter the selected Alert ID: ";
	std::cin >> inString;
	
	wmis::WmisMessage msg;
	msg.setContractId(NOT_WCP_CONTRACT_ID);
	msg.setPrototypeId("reqUgsCommFailureDetail");
	msg.setTransactionId(77);
	wmis::GUIDTypeSerialized data;
	data.gUIDType = inString;
	data.writeToWmisMessage(msg, "alertGuid");
	sc::ScStatus status = m_wcpServer->send(msg);
	std::cout << "sent the reqUgsAlertTamperDetail command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
	std::cout << statusStr << std::endl;
}

void Sender::reqClearAcked()
{
	sc::String inString;
	std::cout << "Enter the selected Alert ID: ";
	std::cin >> inString;
	
	wmis::WmisMessage msg;
	msg.setContractId(NOT_WCP_CONTRACT_ID);
	msg.setPrototypeId("reqClearCurrentUgsAlert");
	msg.setTransactionId(21);
	wmis::GUIDTypeSerialized data;
	data.gUIDType = inString;
	data.writeToWmisMessage(msg, "alertGuid");
	sc::ScStatus status = m_wcpServer->send(msg);
	std::cout << "sent the reqClearCurrentUgsAlert command ";
	sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
	std::cout << statusStr << std::endl;
}

//-----------------------------------------------------------------------------
// TO messages

