#include <iostream>
#include <ScBasicTypes.h>
#include <ScGenericStatus.h>
#include "StandinWcpServer.h"
#include "StandinWssServer.h"
#include "GUIDTypeSerialized.h"

#ifndef WMIS_SIM_SENDER_H
#define WMIS_SIM_SENDER_H

class Sender
{
  public:
    
    static const sc::String WCP_CONTRACT_ID;
    static const sc::String CURRENT_ALERTS_WSS_CONTRACT_ID;
    static const sc::String HISTORY_ALERTS_WSS_CONTRACT_ID;
    static const sc::String ALERT_COUNTS_WSS_CONTRACT_ID;
    
    Sender(
        wmis::StandinWcpServer* wcpServer,
        wmis::StandinWssServer* wssServer);
        
    static void* runThread(void* arg);
    
    void mainMenu(Sender* sender);
    void wssMenu(Sender* sender, sc::String contractId);

    void subWss(sc::String contractId);
    void stopWss(sc::String contractId);
    void startWss(sc::String contractId);
    void unsubWss(sc::String contractId);
    
    void reqTamperDetails();
    void reqCbrnDetails();
    void reqNoAckDetails();
    void reqClearAcked();

    pthread_t m_thread; 

    wmis::StandinWcpServer* m_wcpServer;
    wmis::StandinWssServer* m_wssServer;
    
};

#endif // WMIS_SIM_SENDER_H
