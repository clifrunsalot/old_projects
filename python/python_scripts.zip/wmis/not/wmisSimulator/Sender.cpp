#include <iostream>
#include <ScBasicTypes.h>
#include <ScGenericStatus.h>
#include <WmisMessage.h>
#include <WssMessage.h>
#include "Sender.h"
#include "StandinWcpServer.h"
#include "StandinWssServer.h"
#include "GUIDTypeSerialized.h"
#include "UgsCurrentAlertsQueryTypeSerialized.h"

const sc::String Sender::WCP_CONTRACT_ID =
    "id_fcccme_not_ui0073_srv_SRV0073";
const sc::String Sender::CURRENT_ALERTS_WSS_CONTRACT_ID =
    "id_fcccme_not_ui0073_wss_UgsCurrentAlerts";
const sc::String Sender::HISTORY_ALERTS_WSS_CONTRACT_ID =
    "id_fcccme_not_ui0073_wss_UgsHistoryAlerts";
const sc::String Sender::ALERT_COUNTS_WSS_CONTRACT_ID =
    "id_fcccme_not_ui0073_wss_UgsTotalUnacknowledgedAlertCounts";

Sender::Sender(
    wmis::StandinWcpServer* wcpServer,
    wmis::StandinWssServer* wssServer) :
        m_wcpServer(wcpServer),
        m_wssServer(wssServer),
        m_thread(0)
{
    pthread_create(&m_thread, NULL, runThread, (void*)(this));
}

void* Sender::runThread(void* arg)
{
    Sender* sender = static_cast<Sender*>(arg);

    do
    {
        sender->mainMenu(sender);
    }
    while(true);
}

void Sender::mainMenu(Sender* sender)
{
    int choice = 0;

    std::cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" << std::endl;
    std::cout << "          MENU - Notification Service            " << std::endl;
    std::cout << "                                                 " << std::endl;
    std::cout << " WSS Messages:                                   " << std::endl;
    std::cout << " 1.  Current alerts                              " << std::endl;
    std::cout << " 2.  History alerts                              " << std::endl;
    std::cout << " 3.  Alert counts                                " << std::endl;
    std::cout << "                                                 " << std::endl;
    std::cout << " WCP Messages:                                   " << std::endl;
    std::cout << " 4.  Request Tamper Alert details (implicit ack) " << std::endl;
    std::cout << " 5.  Request CBRN Alert details (implicit ack)   " << std::endl;
    std::cout << " 6.  Request No Ack Alert details (implicit ack) " << std::endl;
    std::cout << " 7.  Clear acknowledged alerts                   " << std::endl;
    std::cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" << std::endl;
    std::cout << "choice> ";

    std::cin >> choice;

    switch (choice)
    {
        case 1:
            sender->wssMenu(sender, CURRENT_ALERTS_WSS_CONTRACT_ID);
            break;
        case 2:
            sender->wssMenu(sender, HISTORY_ALERTS_WSS_CONTRACT_ID);
            break;
        case 3:
            sender->wssMenu(sender, ALERT_COUNTS_WSS_CONTRACT_ID);
            break;
        case 4:
            sender->reqTamperDetails();
            break;
        case 5:
            sender->reqCbrnDetails();
            break;
        case 6:
            sender->reqNoAckDetails();
            break;
        case 7:
            sender->reqClearAcked();
            break;
        default:
            std::cout << "Invalid menu choice - try again." << std::endl;
            break;
    }
}

void Sender::wssMenu(Sender* sender, sc::String contractId)
{
    int choice = 0;

    std::cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" << std::endl;
    std::cout << "         MENU - WSS Message          " << std::endl;
    std::cout << "                                     " << std::endl;
    std::cout << " Choose an action for contract ID:   " << std::endl;
    std::cout << "     " << contractId << std::endl;
    std::cout << "                                     " << std::endl;
    std::cout << " 1.  Subscribe                       " << std::endl;
    std::cout << " 2.  Suspend                         " << std::endl;
    std::cout << " 3.  Resume                          " << std::endl;
    std::cout << " 4.  Unsubscribe                     " << std::endl;
    std::cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" << std::endl;
    std::cout << "choice> ";
    
    std::cin >> choice;

    switch (choice)
    {
        case 1:
            sender->subWss(contractId);
            break;
        case 2:
            sender->stopWss(contractId);
            break;
        case 3:
            sender->startWss(contractId);
            break;
        case 4:
            sender->unsubWss(contractId);
            break;
        default:
            std::cout << "Invalid menu choice - try again." << std::endl;
            break;
    }
}

void Sender::subWss(sc::String contractId)
{
    wmis::WssMessage msg;
    msg.setContractId(contractId);
    msg.setAction(wmis::WssMessage::SUBSCRIBE);
    msg.setDispatchId("1234567890");
    wmis::UgsCurrentAlertsQueryTypeSerialized queryData;
    queryData.neededOneParameter = "dummy";
    queryData.writeToWmisMessage(msg, "WssData");
    std::vector<sc::String> usedParams;
    usedParams.push_back("dummy");
    msg.setUsedParametersList(usedParams);
    sc::ScStatus status = m_wssServer->send(msg, contractId);
    std::cout << "sent the subscribe command ";
    sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
    std::cout << statusStr << std::endl;
}

void Sender::stopWss(sc::String contractId)
{
    wmis::WssMessage msg;
    msg.setContractId(contractId);
    msg.setAction(wmis::WssMessage::STOP_SUBSCRIPTION);
    msg.setDispatchId("1234567890");
    sc::ScStatus status = m_wssServer->send(msg, contractId);
    std::cout << "sent the stop command ";
    sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
    std::cout << statusStr << std::endl;
}

void Sender::startWss(sc::String contractId)
{
    wmis::WssMessage msg;
    msg.setContractId(contractId);
    msg.setAction(wmis::WssMessage::START_SUBSCRIPTION);
    msg.setDispatchId("1234567890");
    sc::ScStatus status = m_wssServer->send(msg, contractId);
    std::cout << "sent the start command ";
    sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
    std::cout << statusStr << std::endl;
}

void Sender::unsubWss(sc::String contractId)
{
    wmis::WssMessage msg;
    msg.setContractId(contractId);
    msg.setAction(wmis::WssMessage::UNSUBSCRIBE);
    msg.setDispatchId("1234567890");
    sc::ScStatus status = m_wssServer->send(msg, contractId);
    std::cout << "sent the unsubscribe command ";
    sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
    std::cout << statusStr << std::endl;
}

void Sender::reqTamperDetails()
{
    sc::String inString;
    std::cout << "Enter the selected Alert ID: ";
    std::cin >> inString;

    wmis::WmisMessage msg;
    msg.setContractId(WCP_CONTRACT_ID);
    msg.setPrototypeId("reqUgsAlertTamperDetail");
    msg.setTransactionId(77);
    wmis::GUIDTypeSerialized data;
    data.gUIDType = inString;
    data.writeToWmisMessage(msg, "alertGuid");
    sc::ScStatus status = m_wcpServer->send(msg);
    std::cout << "sent the reqUgsAlertTamperDetail command ";
    sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
    std::cout << statusStr << std::endl;
}

void Sender::reqCbrnDetails()
{
    sc::String inString;
    std::cout << "Enter the selected Alert ID: ";
    std::cin >> inString;
    
    wmis::WmisMessage msg;
    msg.setContractId(WCP_CONTRACT_ID);
    msg.setPrototypeId("reqUgsRadiationDetail");
    msg.setTransactionId(77);
    wmis::GUIDTypeSerialized data;
    data.gUIDType = inString;
    data.writeToWmisMessage(msg, "alertGuid");
    sc::ScStatus status = m_wcpServer->send(msg);
    std::cout << "sent the reqUgsAlertTamperDetail command ";
    sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
    std::cout << statusStr << std::endl;
}

void Sender::reqNoAckDetails()
{
    sc::String inString;
    std::cout << "Enter the selected Alert ID: ";
    std::cin >> inString;
    
    wmis::WmisMessage msg;
    msg.setContractId(WCP_CONTRACT_ID);
    msg.setPrototypeId("reqUgsCommFailureDetail");
    msg.setTransactionId(77);
    wmis::GUIDTypeSerialized data;
    data.gUIDType = inString;
    data.writeToWmisMessage(msg, "alertGuid");
    sc::ScStatus status = m_wcpServer->send(msg);
    std::cout << "sent the reqUgsAlertTamperDetail command ";
    sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
    std::cout << statusStr << std::endl;
}

void Sender::reqClearAcked()
{
    sc::String inString;
    std::cout << "Enter the selected Alert ID: ";
    std::cin >> inString;
    
    wmis::WmisMessage msg;
    msg.setContractId(WCP_CONTRACT_ID);
    msg.setPrototypeId("reqClearCurrentUgsAlert");
    msg.setTransactionId(21);
    wmis::GUIDTypeSerialized data;
    data.gUIDType = inString;
    data.writeToWmisMessage(msg, "alertGuid");
    sc::ScStatus status = m_wcpServer->send(msg);
    std::cout << "sent the reqClearCurrentUgsAlert command ";
    sc::String statusStr = (status == SC_SUCCESS) ? "successfully" : "unsuccessfully"; 
    std::cout << statusStr << std::endl;
}
