#include <iostream>
#include <ScBasicTypes.h>
#include <ScGenericStatus.h>
#include <WmisMessage.h>
#include <WssMessage.h>
#include "StandinWcpServer.h"
#include "StandinWssServer.h"

#ifndef WMIS_SIM_RECEIVER_H
#define WMIS_SIM_RECEIVER_H

class Receiver
{
  public:
    
    Receiver(
        wmis::StandinWcpServer* wcpServer,
        wmis::StandinWssServer* wssServer);
  
    static void* runThread(void* arg);
  
    void processWcpMessage(wmis::WmisMessage msg);

    void processWssMessage(wmis::WssMessage msg);
    
    pthread_t m_thread; 

    wmis::StandinWcpServer* m_wcpServer;
    wmis::StandinWssServer* m_wssServer;
};

#endif // WMIS_SIM_RECEIVER_H
