//-----------------------------------------------------------------------------
// COMPANY NAME: Raytheon Company
// COPYRIGHT: Copyright (c) 2008 Raytheon Company
// UNPUBLISHED WORK
// ALL RIGHTS RESERVED
// PROJECT NAME: FCS BCME
// CONTRACT NUMBER: 3EC1721
//
// @author  saschi          BCME-1241
// @version BCME-1241       2008-JAN-28     Initial version.
//
//-----------------------------------------------------------------------------

#include <ScBasicTypes.h>
#include <ScGenericStatus.h>
#include "StandinWcpServer.h"
#include "StandinWssServer.h"
#include "Sender.h"
#include "Receiver.h"

#ifndef WMIS_SIM_SIMULATOR_H
#define WMIS_SIM_SIMULATOR_H

using fcccme::fec::test::Sender;
using fcccme::fec::test::Receiver;

class WmisSimulator
{
  public:
  
    WmisSimulator();
    virtual ~WmisSimulator();
    
    sc::ScStatus startUp(sc::String sessionId);
  
  private:
    
    wmis::StandinWcpServer* m_wcpServer;
    wmis::StandinWssServer* m_wssServer;
    Sender* m_sender;
    Receiver* m_receiver;
};

#endif // WMIS_SIM_SIMULATOR_H
