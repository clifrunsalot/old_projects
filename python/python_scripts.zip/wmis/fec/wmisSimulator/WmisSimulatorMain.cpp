//-----------------------------------------------------------------------------
// COMPANY NAME: Raytheon Company
// COPYRIGHT: Copyright (c) 2008 Raytheon Company
// UNPUBLISHED WORK
// ALL RIGHTS RESERVED
// PROJECT NAME: FCS BCME
// CONTRACT NUMBER: 3EC1721
//
// @author  saschi          BCME-1241
// @version BCME-1241       2008-JAN-28     Initial version.
//
//-----------------------------------------------------------------------------

#include <iostream>
#include <ScBasicTypes.h>
#include <ScGenericStatus.h>
#include "WmisSimulator.h"

int main (sc::Int argc, sc::Char** argv)
{
    // the name of the executable
    sc::String progName(argv[0]);

    // a variable to hold the session id
    sc::String sessionId = "";

    // a variable to hold the option
    sc::Int option(0);

    // Get all options
    while ((option = getopt(argc, argv, "s:")) != -1)
    {
        switch (option)
        {
            case 's':   // (-s) Argument defining the Session Id
            {
                // Any args?
                if (optarg != NULL)
                {
                    sessionId = optarg;
                }
                break;
            }
            default:
            {
                std::cerr << "The option [" << option << "] is not supported." <<
                std::endl;
                break;
            }
        }
    }

    if (sessionId != "")
    {
        WmisSimulator sim;
        sc::ScStatus status = sim.startUp(sessionId);
        if (status == SC_SUCCESS)
        {
            // Just sit around and wait for Ctrl-C.
            while (true)
            {
                sleep(1);
            }
        }
        else
        {
            std::cerr << "Error: unable to start the simulator" << std::endl;
        }
    }
    else
    {
        // print out a usage statement
        std::cerr << "Usage: ";
        std::cerr << progName << " ";
        std::cerr << "-s <session id> ";
        std::cerr << std::endl;
    }
}
