//-----------------------------------------------------------------------------
// COMPANY NAME: Raytheon Company
// COPYRIGHT: Copyright (c) 2008 Raytheon Company
// UNPUBLISHED WORK
// ALL RIGHTS RESERVED
// PROJECT NAME: FCS BCME
// CONTRACT NUMBER: 3EC1721
//
// @author  saschi          BCME-1241
// @version BCME-1241       2008-JAN-28     Initial version.
//
//-----------------------------------------------------------------------------

#include <iostream>
#include <ScBasicTypes.h>
#include <ScGenericStatus.h>
#include "WmisSimulator.h"
#include "Sender.h"
#include "Receiver.h"
#include <set>

using fcccme::fec::test::Sender;
using fcccme::fec::test::Receiver;

WmisSimulator::WmisSimulator() :
    m_wcpServer(0),
    m_wssServer(0),
    m_sender(0),
    m_receiver(0)
{
}

//-----------------------------------------------------------------------------

WmisSimulator::~WmisSimulator()
{
}

//-----------------------------------------------------------------------------

sc::ScStatus WmisSimulator::startUp(sc::String sessionId)
{
    sc::ScStatus status = SC_SUCCESS;
    
    const sc::String USER_NAME = "default";
    const sc::String ROLE_NAME = "NO_ROLE";

    std::set<sc::String> wcpContracts;
    wcpContracts.insert(Sender::WCP_CONTRACT_ID);

    std::set<sc::String> wssContracts;
    wssContracts.insert(Sender::EFFECTOR_WSS_CONTRACT_ID);
    wssContracts.insert(Sender::FIRE_MISSIONS_WSS_CONTRACT_ID);
    wssContracts.insert(Sender::MISSION_PROGRESSION_WSS_CONTRACT_ID);
    wssContracts.insert(Sender::MISSION_TARGET_WSS_CONTRACT_ID);
    wssContracts.insert(Sender::MTO_WSS_CONTRACT_ID);
    wssContracts.insert(Sender::OBSERVER_WSS_CONTRACT_ID);

    m_wcpServer = wmis::StandinWcpServer::getInstance(
        sessionId, wcpContracts, USER_NAME, ROLE_NAME);

    m_wssServer = wmis::StandinWssServer::getInstance(
        sessionId, wssContracts, USER_NAME, ROLE_NAME);

    if (m_wcpServer != 0 && m_wssServer != 0)
    {
        std::cout << "Waiting for connections..." << std::endl;
        while (!m_wcpServer->isConnected(Sender::WCP_CONTRACT_ID) &&
            !m_wssServer->isConnected(Sender::EFFECTOR_WSS_CONTRACT_ID) &&
            !m_wssServer->isConnected(Sender::FIRE_MISSIONS_WSS_CONTRACT_ID) &&
            !m_wssServer->isConnected(Sender::MISSION_PROGRESSION_WSS_CONTRACT_ID) &&
            !m_wssServer->isConnected(Sender::MISSION_TARGET_WSS_CONTRACT_ID) &&
            !m_wssServer->isConnected(Sender::MTO_WSS_CONTRACT_ID) &&
            !m_wssServer->isConnected(Sender::OBSERVER_WSS_CONTRACT_ID))
        {
            sleep(1);
        }
        std::cout << "All connections established..." << std::endl;
    
        std::cout << "Creating sender thread" << std::endl;
        m_sender = new Sender(m_wcpServer, m_wssServer);

        std::cout << "Creating receiver thread" << std::endl;
        m_receiver = new Receiver(m_wcpServer, m_wssServer);
    }
    else
    {
        std::cout << "Error creating servers" << std::endl;
        status = SC_FAILED;
    }
    
    return status;
}
