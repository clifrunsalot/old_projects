#include<iostream.h>
void main()
{
	 int day;
	 char reply='Y';
	 
	 cout<<"Enter the day of the week as a number ";
	 cin>>day;
	 do
	 {
	 // Write the switch statement to display the name of the day 
	 // based on the day no.entered by the user. 
     
	 cout<<endl<<"Do you want to continue :";
	 cin>>reply; 
     }while(reply=='Y');
}
