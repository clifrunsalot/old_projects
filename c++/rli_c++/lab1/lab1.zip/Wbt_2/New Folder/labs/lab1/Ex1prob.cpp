#include <iostream.h>
void main()
{
	int num1,num2,counter;
	cout<<"Enter the starting number of the range :";
	cin>>num1;
	cout<<"Enter the last number of the range :";
	cin>>num2;
   
		
   	// Write a for loop to display all even numbers between num1 and num2
   		{
			if(counter%2==0)
   		    cout<<counter<<endl;
		}

}











