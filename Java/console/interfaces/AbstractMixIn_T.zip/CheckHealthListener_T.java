import java.io.*;

interface CheckHealthListener_T
{
	int processCheckHealth();
}

