import java.io.*;

interface TerminateListener_T
{
	void processTerminate();
}

