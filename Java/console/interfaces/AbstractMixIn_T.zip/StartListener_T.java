import java.io.*;

interface StartListener_T
{
	void processStart();
}

