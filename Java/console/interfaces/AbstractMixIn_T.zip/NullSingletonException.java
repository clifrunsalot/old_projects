public class NullSingletonException extends RuntimeException
{
}
