/**
 * 
 */
package refresher.armediatest.com;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author clif
 *
 */
public class ExceptionExamples {

	private static void logIt(String s) {
		System.out.println(s);
	}

	private static void useExceptions() {

		try {

			String[] myStrList = { "two", "1" };
			List<String> myList = new ArrayList<String>(Arrays.asList(myStrList));
			for (String s : myList) {
				if (Integer.parseInt(s) == 1)
					throw new NullPointerException();
				else
					throw new NumberFormatException();
			}

		} catch (NullPointerException | NumberFormatException e) {
			if (e instanceof NullPointerException) {
				logIt("caught npe");
			} else if (e instanceof NumberFormatException) {
				logIt("caught iobe");
			}
		} finally {
			logIt("Done");
		}

		final String myFile = "/Users/clif/event.txt";

		String line = "";
		try (BufferedReader br = new BufferedReader(new FileReader(myFile))) {
			while ((line = br.readLine()) != null) {
				logIt(line);
				if (line.contains("kittens"))
					throw new IOException();
			}
		} catch (IOException fnfe) {
			logIt("Caught IOException");
		} finally {
			logIt("Done");
		}

	}

	public static void main(String[] args) {
		ExceptionExamples.useExceptions();
	}

}
