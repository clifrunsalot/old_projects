/**
 * 
 */
package refresher.armediatest.com;

/**
 * @author clif
 *
 */
public class Question4 {

	/**
	 * Finds largest integer in array.
	 * 
	 * @param intAry
	 * @return largest value
	 */
	static int getLargestInt(int[] intAry) {

		int largest = -1_000_000_000;

		for (int i : intAry) {
			if (i > largest) {
				largest = i;
			}
		}

		return largest;
	}

	public static void main(String[] args) {
		 
//Joanns-MacBook-Pro:~ clif$ echo "12, 34, 1, 0, 999, 1000999, -2" | tr "," "\n"| sed 's/ //g' | sort -n
//-2
//0
//1
//12
//34
//999
//1000999 <-----LARGEST
//Joanns-MacBook-Pro:~ clif$ 
		 
		int[] iAry = { 12, 34, 1, 0, 999, 1_000_999, -2, };
		System.out.println("Largest Value: " + getLargestInt(iAry));
	
//		Joanns-MacBook-Pro:~ clif$ echo "-2, -1, -999, -1000999, -999" | tr "," "\n"| sed 's/ //g' | sort -n
//		-1000999
//		-999
//		-999
//		-2
//		-1 <--------LARGEST
//		Joanns-MacBook-Pro:~ clif$

		iAry = new int[] { -2, -1, -999, -1_000_999, -999 };
		System.out.println("Largest Value: " + getLargestInt(iAry));

//		Joanns-MacBook-Pro:~ clif$ echo "-999999, -888888, -777777, -666666, 0, 1" | tr "," "\n"| sed 's/ //g' | sort -n
//		-999999
//		-888888
//		-777777
//		-666666
//		0
//		1 <---- LARGEST
//		Joanns-MacBook-Pro:~ clif$ 

		iAry = new int[] { -999999, -888888, -777777, -666666, 0, 1 };
		System.out.println("Largest Value: " + getLargestInt(iAry));
	}

}
