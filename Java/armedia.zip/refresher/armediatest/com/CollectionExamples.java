/**
 * 
 */
package refresher.armediatest.com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author clif
 *
 */
public class CollectionExamples {

	private static void useSet() {
		String[] aryA = { "one", "two", "three", "four", "a", "a" };
		String[] aryB = { "one", "three", "four", "a", "a" };

		Set<String> setA = new TreeSet<>(Arrays.asList(aryA));
		Set<String> setB = new TreeSet<>(Arrays.asList(aryB));

		System.out.println("======== Set A ========");
		Iterator<String> iterA = setA.iterator();
		while (iterA.hasNext()) {
			System.out.println(iterA.next());
		}

		System.out.println("======== Set B ========");
		System.out.println(setB);

		System.out.println("======== Intersection ========");
		Set<String> intersection = new TreeSet<String>(setA);
		intersection.retainAll(setB);
		System.out.println(intersection);

		System.out.println("======== Union =========");
		Set<String> union = new TreeSet<String>(setA);
		union.addAll(setB);
		System.out.println(union);

	}

	private static void useList() {

		String[] origAry = { "1", "one", "two", "three", "four", "b", "z" };

		List<String> listA = Arrays.asList(origAry);

		System.out.println("========= List A ===========");
		System.out.println(listA);

		System.out.println("========= Forward ==========");
		for (String s : listA) {
			System.out.println(s);
		}

		System.out.println("========= Reverse =========");
		for (ListIterator<String> iter = listA.listIterator(listA.size()); iter.hasPrevious();) {
			System.out.println(iter.previous());
		}

		System.out.println("======== Unsorted listB =========");
		System.out.println(listA);
		System.out.println("======== Sorted listB =========");
		List<String> listB = new ArrayList<String>(listA);
		Collections.sort(listB);
		System.out.println(listB);
	}

	private static void useQueue() {

		Queue<Integer> queueA = new LinkedList<Integer>();
		int val = 0;
		for (int i = 0; i <= 10; i++) {
			val = Integer.valueOf(new Random().nextInt());
			if (!queueA.offer(val)) {
				logIt("Cannot add value");
			}
		}
		logIt("========= Original queueA ==========");
		logIt(queueA.toString());

		logIt("Removing a couple of items from queueA");
		Queue<Integer> queueB = new LinkedList<Integer>(queueA);
		String bad = "";
		for (int i = 0; i < 4; i++) {
			bad = (queueB.poll() == null) ? "Cannot remove anymore" : "";
			if (!bad.trim().isEmpty())
				logIt(bad);
		}
		logIt(queueB.toString());

		logIt("========= Original Unsort Priority queueA ==========");
		logIt(queueA.toString());
		logIt("========= Sort Priority queueA ==========");
		Queue<Integer> queueC = new PriorityQueue<Integer>(queueA);
		List<Integer> sortedFromQueue = new ArrayList<>();
		while (!queueC.isEmpty()) {
			sortedFromQueue.add(queueC.remove());
		}
		logIt(sortedFromQueue.toString());

	}

	private static void useDeque() {

		Deque<Integer> dequeA = new LinkedList<Integer>();
		int val = 0;
		for (int i = 0; i <= 10; i++) {
			val = Integer.valueOf(new Random().nextInt());
			if (!dequeA.offer(val)) {
				logIt("Cannot add value");
			}
		}
		logIt("========= Original dequeA ==========");
		logIt(dequeA.toString());

		logIt("========= Added 2 to the front of dequeA ==========");
		Deque<Integer> dequeB = new LinkedList<Integer>(dequeA);
		dequeB.offerFirst(1);
		dequeB.offerFirst(2);
		logIt(dequeB.toString());

		logIt("========= Added 2 to the end of dequeA ==========");
		Deque<Integer> dequeC = new LinkedList<Integer>(dequeB);
		dequeC.offerLast(10);
		dequeC.offerLast(11);
		logIt(dequeC.toString());

		logIt("========= Removed 2 from front of dequeA ==========");
		Deque<Integer> dequeD = new LinkedList<Integer>(dequeC);
		dequeD.pollFirst();
		dequeD.pollFirst();
		logIt(dequeD.toString());

		logIt("========= Removed 2 from end of dequeA ==========");
		Deque<Integer> dequeE = new LinkedList<Integer>(dequeD);
		dequeE.pollLast();
		dequeE.pollLast();
		logIt(dequeE.toString());
	}

	private static void useMap() {

		String[] words = new String[] { "a", "z", "b", "f", "f", "a", "a", "one", "z", "z", "one" };
		Map<String, Integer> myMap = new HashMap<>();
		for (int i = 0; i < words.length; i++) {
			Integer freq = myMap.get(words[i]);
			logIt("freq: " + freq + ", word: " + words[i]);
			myMap.put(words[i], freq == null ? 1 : freq + 1);
		}

		logIt(myMap.toString());

	}

	private static void logIt(String s) {
		System.out.println(s);
	}

	public static void main(String[] args) {
		CollectionExamples.useSet();
		CollectionExamples.useList();
		CollectionExamples.useQueue();
		CollectionExamples.useDeque();
		CollectionExamples.useMap();
	}

}
