/**
 * 
 */
package refresher.armediatest.com;

/**
 * @author clif
 *
 */
public class Question3a {
	public static void main(String[] args) {
		String s1 = new String("hello");
		String s2 = new String("hello");

		if (s1.equals(s2))
			System.out.println("equal");
		else
			System.out.println("not equal");
	}
}
