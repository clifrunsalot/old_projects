/**
 * 
 */
package refresher.armediatest.com;

/**
 * @author clif
 *
 */
public class ArmediaTest {

	private static Question1 question;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		question = new Question1();
		question.test1();

	}

}
