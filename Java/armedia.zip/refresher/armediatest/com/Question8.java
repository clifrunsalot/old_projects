/**
 * 
 */
package refresher.armediatest.com;

/**
 * @author clif
 *
 */
public class Question8 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
