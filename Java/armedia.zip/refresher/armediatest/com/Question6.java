/**
 * 
 */
package refresher.armediatest.com;

/**
 * @author clif
 *
 */
public class Question6 {

	public static void printIt() {
		String name;
		int i;
		boolean startWord;

		name = "Richard M. Nixon";
		startWord = true;
		for (i = 0; i < name.length(); i++) {
			if (startWord)
				System.out.println(name.charAt(i));
			if (name.charAt(i) == ' ')
				startWord = true;
			else
				startWord = false;
		}

	}

	public static void main(String[] args) {
		Question6.printIt();
	}

}
